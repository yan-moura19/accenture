package acc.br.pessoaswaggger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PessoaSwagggerApplication {

    public static void main(String[] args) {
        SpringApplication.run(PessoaSwagggerApplication.class, args);
    }

}
