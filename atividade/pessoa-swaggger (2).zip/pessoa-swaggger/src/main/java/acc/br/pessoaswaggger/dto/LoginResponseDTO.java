package acc.br.pessoaswaggger.dto;

public record LoginResponseDTO(String token){

        }
