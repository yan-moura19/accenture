package acc.br.pessoaswaggger.dto;

public record AuthenticationDTO(String login, String password){

        }
