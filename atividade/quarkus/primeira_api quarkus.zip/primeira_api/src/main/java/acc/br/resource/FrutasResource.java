package acc.br.resource;

import acc.br.model.Fruta;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
@Path("/frutas")
public class FrutasResource {

    private static final Logger LOGGER = LoggerFactory.getLogger(FrutasResource.class);

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Fruta> list() {
        return Fruta.listAll();
    }

    @POST
    @Transactional
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response novaFruta(@Valid Fruta fruta) {
        LOGGER.info("Criando nova fruta");
        fruta.persist();
        LOGGER.info("Fruta criada");
        return Response.status(Response.Status.CREATED).entity(fruta).build();
    }

    @DELETE
    @Path("/{id}")
    @Transactional
    @Produces(MediaType.APPLICATION_JSON)
    public Response deletarFruta(@PathParam("id") Long id) {
        LOGGER.info("Tentando deletar fruta com ID: {}", id);
        Fruta fruta = Fruta.findById(id);
        if (fruta == null) {
            LOGGER.warn("Fruta  não encontrada.");
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        fruta.delete();
        LOGGER.info("Fruta deletada com sucesso: {}", fruta.nome);
        return Response.ok().entity("{\"id\":" + id + "}").build();
    }
}