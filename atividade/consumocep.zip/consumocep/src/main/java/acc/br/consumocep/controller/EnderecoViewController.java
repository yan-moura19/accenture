package acc.br.consumocep.controller;

import acc.br.consumocep.model.Endereco;
import acc.br.consumocep.service.EnderecoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/ceps/view")
public class EnderecoViewController {

    @Autowired
    EnderecoService enderecoService;

    @GetMapping
    public ModelAndView listar() {
        List<Endereco> listaEndereco = enderecoService.listarTodos();

        ModelAndView modelAndView = new ModelAndView("listaCeps");
        modelAndView.addObject("cepsList", listaEndereco);


        return modelAndView;
    }
}

