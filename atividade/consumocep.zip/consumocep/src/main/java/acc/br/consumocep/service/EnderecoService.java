package acc.br.consumocep.service;

import acc.br.consumocep.model.Endereco;
import acc.br.consumocep.repository.EnderecoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EnderecoService {
    @Autowired
    private CepService cepService;

    @Autowired
    private EnderecoRepository enderecoRepository;

    public Endereco buscaEnderecoPorCep(String cep) {
        Endereco endereco = cepService.buscaEnderecoPorCep(cep);
        if (endereco != null) {
            endereco.setCep(cep);  // Certifique-se de que o CEP está sendo salvo
            enderecoRepository.save(endereco);
        }
        return endereco;
    }
    public List<Endereco> listarTodos() {
        return enderecoRepository.findAll();
    }
}
