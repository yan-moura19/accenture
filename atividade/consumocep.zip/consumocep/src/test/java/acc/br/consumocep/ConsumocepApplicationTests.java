package acc.br.consumocep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumocepApplicationTests {

    @Test
    void contextLoads() {
    }

}
