package acc.br.contatos.controller;

import acc.br.contatos.model.Contato;
import acc.br.contatos.model.Student;
import acc.br.contatos.service.ContatosService;
import acc.br.contatos.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/contatos-estudantes")
public class ViewController {



        @Autowired
        private ContatosService contatosService;

        @Autowired
        private StudentService studentService;

        @GetMapping
        public ModelAndView listar() {
            List<Contato> listaContatos = contatosService.findAll();
            List<Student> listaEstudantes = studentService.getAllStudent();

            ModelAndView modelAndView = new ModelAndView("contatos-estudantes");
            modelAndView.addObject("contatos", listaContatos);
            modelAndView.addObject("students", listaEstudantes);

            return modelAndView;
        }
    }
