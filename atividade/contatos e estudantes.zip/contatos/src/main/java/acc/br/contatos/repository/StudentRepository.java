package acc.br.contatos.repository;

import acc.br.contatos.model.Student;
import org.springframework.data.repository.CrudRepository;


public interface StudentRepository extends CrudRepository<Student, Integer>
{
}
