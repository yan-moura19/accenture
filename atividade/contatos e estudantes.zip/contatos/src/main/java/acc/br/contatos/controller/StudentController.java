package acc.br.contatos.controller;

import acc.br.contatos.model.Contato;
import acc.br.contatos.model.Student;
import acc.br.contatos.service.ContatosService;
import acc.br.contatos.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @GetMapping
    public ModelAndView listar() {
        List<Student> lista = studentService.getAllStudent();

        ModelAndView modelAndView = new ModelAndView("students");
        modelAndView.addObject("students", lista);

        return modelAndView;
    }


}