package acc.br.contatos.service;

import acc.br.contatos.model.Contato;
import acc.br.contatos.repository.ContatosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;



@Service
public class ContatosService {

    @Autowired
    private ContatosRepository contatosRepository;

    public List<Contato> findAll() {
        return contatosRepository.findAll();
    }
}