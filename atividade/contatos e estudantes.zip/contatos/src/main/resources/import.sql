insert into Contato (id, nome, email) values (1, 'William Douglas', 'williamdouglas@gmail.com');
insert into Contato (id, nome, email) values (2, 'Al Ries', 'alries@hotmail.com');
insert into Contato (id, nome, email) values (3, 'Mortimer J. Adler', 'mortimeradler@gmail.com');
insert into Contato (id, nome, email) values (4, 'Christian Barbosa', 'christianbarbosa@gmail.com');

insert into student (id, name,age, email) values (1, 'William Douglas',22, 'williamdouglas@gmail.com');
insert into student (id, name,age, email) values (2, 'Al Ries', 18, 'alries@hotmail.com');
insert into student (id, name,age, email) values (3, 'Mortimer J. Adler', 17, 'mortimeradler@gmail.com');
insert into student (id, name,age, email) values (4, 'Christian Barbosa', 15,'christianbarbosa@gmail.com');

