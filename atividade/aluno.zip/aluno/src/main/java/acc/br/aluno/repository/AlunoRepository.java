package acc.br.aluno.repository;

import acc.br.aluno.model.Aluno;
import org.springframework.data.repository.CrudRepository;

public interface AlunoRepository  extends CrudRepository<Aluno, Integer> {

}
