package acc.br.student_api.model;

import jakarta.persistence.*;
import lombok.Data;
@Data
@Entity

@Table

public class Student {

    @Id

    private int id;

    @Column
    private String name;

    @Column
    private int age;
    @Column
    private String Email;


}
